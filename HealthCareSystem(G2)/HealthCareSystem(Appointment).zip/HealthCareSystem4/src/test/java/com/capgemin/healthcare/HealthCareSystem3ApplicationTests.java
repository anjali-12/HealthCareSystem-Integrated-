package com.capgemin.healthcare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCareSystem3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
