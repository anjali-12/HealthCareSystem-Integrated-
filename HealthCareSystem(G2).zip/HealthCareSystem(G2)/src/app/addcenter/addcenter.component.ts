import { Component, OnInit } from '@angular/core';
import {Center} from '../center'; 
import {CentersService} from '../centers.service';

@Component({
  selector: 'app-addcenter',
  templateUrl: './addcenter.component.html',
  styleUrls: ['./addcenter.component.css']
})
export class AddcenterComponent implements OnInit {
  center: Center=new Center();
  submitted=false;
  msg:String;
  errorMsg:String;

  constructor(private centersService:CentersService) { }

  ngOnInit() {
  }
  newCenter(Center){
    this.center=new Center(); 
  }
  save(){
    this.centersService.addCenters(this.center).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.center=new Center()},
      error=>{alert("Invalid details");});
  }
  OnSubmit(){
    this.submitted=true;
    this.save();
  }

}
