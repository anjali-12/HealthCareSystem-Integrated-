import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {CommonModule} from '@angular/common';
import {HttpClient, HttpClientModule } from '@angular/common/http';
import { ViewComponent } from './view/view.component';
import { AddtestComponent } from './addtest/addtest.component';
import { ViewcenterComponent } from './viewcenter/viewcenter.component';
import { AddcenterComponent } from './addcenter/addcenter.component';
import { LoginComponent } from './login/login.component';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { RegistrationComponent } from './registration/registration.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { Appointment } from './center';
import { MakeAppointmentComponent } from './make-appointment/make-appointment.component';
import { ApproveComponent } from './approve/approve.component';
import {  ViewAppointmentComponent } from './view-appointment/view-appointment.component';


@NgModule({
  declarations: [
    AppComponent,ViewComponent, AddtestComponent,ViewcenterComponent, AddcenterComponent,LoginComponent,
    LoginsuccessComponent,
    RegistrationComponent,
    ViewUserComponent,
    AdminComponent,
    HomeComponent,
    ErrorComponent,
    AdminPageComponent,
    ViewAppointmentComponent,
    MakeAppointmentComponent,
    ApproveComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
