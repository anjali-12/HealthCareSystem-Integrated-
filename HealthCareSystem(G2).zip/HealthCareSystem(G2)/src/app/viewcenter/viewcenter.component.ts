import { Component, OnInit } from '@angular/core';
import { Center } from '../center';
import { Tests } from '../center';
import {CentersService} from '../centers.service';


@Component({
  selector: 'app-viewcenter',
  templateUrl: './viewcenter.component.html',
  styleUrls: ['./viewcenter.component.css']
})
export class ViewcenterComponent implements OnInit {
  centers:Center[]=[];
  tests:Tests[];
  modifyCenter=new Center();
  updateDiv:boolean=false;
  msg:string;
  errorMsg:string;
  constructor(private centersService:CentersService ) { }
  ngOnInit () {
    console.log("Am inside view component");
    this.centersService.viewCenters().subscribe(data=>this.centers=data);
    this.centersService.viewTests().subscribe(data=>this.tests=data);
        console.log(this.tests);
    console.log(this.centers);
  }
  deleteCenter(centerId:number){

    if(confirm("Confirm Deletion of Account Id:"+centerId)){
      this.centersService.deleteCenter(centerId)
      .subscribe(data=>{
        this.msg=data;
        this.errorMsg=undefined;
        this.centersService.viewCenters().subscribe(data=>this.centers=data);
        console.log(this.centers);
      },
        error=>{
          this.errorMsg=error.error;
          this.msg=undefined;
        });

    }
  }
    update(centers:Center)
    {
      console.log(JSON.stringify(centers));
      this.modifyCenter=centers;
      this.updateDiv=true;//make update division visible
    }
  cancel()
  {
    this.updateDiv=false;//make update division invisible
  }
  updateCenter(){
    this.updateDiv=false;//make update division invisible
    this.centersService.UpdateCenter(this.modifyCenter)
          .subscribe(data=>{
            this.msg=data;
            this.errorMsg=undefined;
            this.centersService.viewCenters().subscribe(data=>this.centers=data);
            console.log(this.centers);
          },
            error=>{
              this.errorMsg=error.error;
              this.msg=undefined;
            });

  }



}
