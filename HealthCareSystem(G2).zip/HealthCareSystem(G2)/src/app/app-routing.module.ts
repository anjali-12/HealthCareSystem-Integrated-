import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ViewComponent} from './view/view.component';
import {CommonModule} from '@angular/common';
import { AddtestComponent } from './addtest/addtest.component';
import {ViewcenterComponent} from './viewcenter/viewcenter.component';
import {AddcenterComponent} from './addcenter/addcenter.component';
import {LoginComponent} from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { RegistrationComponent } from './registration/registration.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { RegistrationService } from './Services/registration.service';




import {ApproveComponent} from './approve/approve.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { ViewAppointmentComponent } from './view-appointment/view-appointment.component';
import { MakeAppointmentComponent } from './make-appointment/make-appointment.component';
 

const routes: Routes = [
  {path:'viewcenter',component :ViewcenterComponent},
  {path:'addcenter',component :AddcenterComponent},
  
  {path:'add',component: AddtestComponent},
  {path:'view',component: ViewComponent},
  {path:'approve',component: ApproveComponent},
  {path:'login',component:LoginComponent},
  {path:'loginsuccess',component:LoginsuccessComponent},
  {path:'register',component:RegistrationComponent},
  {path:'viewUser',component:ViewUserComponent,canActivate:[RegistrationService]},
  {path:'admin',component:AdminComponent},
  {path:'home',component:HomeComponent},
  {path:'error',component:ErrorComponent},
  {path:'admin-page',component:AdminPageComponent},
  {path:'view-appointment' , component: ViewAppointmentComponent},
  {path:'make-appointment', component:MakeAppointmentComponent,canActivate:[RegistrationService]},
  {path:'approve', component:ApproveComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes),CommonModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
