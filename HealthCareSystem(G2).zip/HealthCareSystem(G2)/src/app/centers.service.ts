import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Center,Tests } from './center';
import { User } from './center';
import { Appointment, NewAppointment } from './center';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class CentersService implements CanActivate{
 
  
  constructor(private http:HttpClient,private router:Router) { }
  
  
  viewCenters():Observable<any>{
    return this.http.get(`http://localhost:6868/`+'centers');
  }
 addCenters(center: Center):Observable<any> {
    return this.http.post(`http://localhost:6868/`+'addcenter', center,{responseType:'text'});
  }
  deleteCenter(centerId: number): Observable<any> {  
    return this.http.delete(`http://localhost:6868/center/${centerId}`,{responseType:'text'});
   
  }  
 
  UpdateCenter(modifyCenter: Center) {
    return this.http.put("http://localhost:6868/update",modifyCenter,{responseType:'text'});
    
  }
 0
  public viewTests():Observable<any>{
   
    return this.http.get("http://localhost:6868/tests");
  }

  public addTest(test:Tests):Observable<any>{
    return this.http.post("http://localhost:6868/addtest",test,{responseType:'text'});
  }

  delTest(testId: number) :Observable<any>{
    console.log("http://localhost:6868/tests/"+testId);
    return this.http.delete("http://localhost:6868/tests/"+testId,{responseType:'text'});
  }
  UpdateTest(modifyTest: Tests) {
    return this.http.put("http://localhost:6868/updateTest",modifyTest,{responseType:'text'});
    
  }

  //UpdateTest(modifyCenter: Center) {
    //return this.http.put("http://localhost:6868/updateTest",modifyCenter,{responseType:'text'});
    
  //}
  viewAppointments():Observable<any>{
    return this.http.get("http://localhost:6585/viewAppointments");
  }
  
  public makeAppointment(newAppointment:NewAppointment):Observable<any>{
    return this.http.post("http://localhost:6585/makeAppointment",newAppointment,{responseType:'text'});
  }
  getCenters():Observable<any> {
    return this.http.get("http://localhost:6868/centers");
  }
  
  getTests():Observable<any> {
    return this.http.get("http://localhost:6868/tests");
  }
  public getUsers():Observable<any>{
    return this.http.get("http://localhost:6566/viewAllUser");
  } 
  approveAppointments(appId: number):Observable<any> {
    return this.http.put("http://localhost:6585/approve",appId,{responseType:'text'});
  }
  public loginUser(user:User):Observable<any>{
    console.log("Login:"+JSON.stringify(user));
    localStorage.setItem("token",JSON.stringify(user));
    return this.http.post("http://localhost:6566/login",user,{responseType:'text'});
  }

  public registerUserFromRemote(user:User):Observable<any>{
    return this.http.post("http://localhost:6566/signup",user,{responseType:'text'});
  }

 
 public viewUser():Observable<any>{
    return this.http.get("http://localhost:6566/viewAllUser");
  } 
  public adminLogin(user:User):Observable<any>{
    console.log("Login:"+JSON.stringify(user));
    localStorage.setItem("token",JSON.stringify(user));
    return this.http.post("http://localhost:6566/admin",user,{responseType:'text'});
  }

  public deleteUserFromRemote(userId:number):Observable<any>{

    return this.http.delete("http://localhost:6566/deleteuser/"+userId,{responseType:'text'});
  }

 /* logout():Observable<any> { console.log("inside service delete"); 
  return this.http.get("http://localhost:6566/user/logout/"); }

 */

canActivate(): boolean  {
  if(localStorage.getItem("token"))
      return true;
  else 
  {
    this.router.navigateByUrl("error");
    return false;
  }
    
}
/* loginUser(user:User){
  console.log("Login:"+JSON.stringify(user));
  localStorage.setItem("token",JSON.stringify(user));
} */
logOut(){
  console.log("LogOut");
localStorage.removeItem("token");
}

}
  
  
  

  


