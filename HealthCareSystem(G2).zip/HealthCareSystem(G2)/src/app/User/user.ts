export class User {
    userId:number;
    emailId:string;
    userName:string;
    userPassword:string;
    contactNo:string;
    gender:string;
    age:number;

        constructor(){}

}
