import { Component, OnInit } from '@angular/core';
import { CentersService } from '../centers.service';

import { Appointment } from '../center';

@Component({
  selector: 'app-view',
  templateUrl: './view-appointment.component.html',
  styleUrls: ['./view-appointment.component.css']
})
export class ViewAppointmentComponent implements OnInit {
appointments:Appointment[]=[];
  constructor(private appointmentService:CentersService) {}

  ngOnInit(){
    this.appointmentService.viewAppointments().subscribe(data=>this.appointments=data);
  }
}

