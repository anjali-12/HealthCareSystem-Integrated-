import { Component, OnInit } from '@angular/core';
import { Tests } from '../center';
import { CentersService } from '../centers.service';

@Component({
  selector: 'app-addtest',
  templateUrl: './addtest.component.html',
  styleUrls: ['./addtest.component.css']
})
export class AddtestComponent implements OnInit {
  test:Tests=new Tests();
  msg:String;
  errorMsg:String;
  constructor(private centersService:CentersService) { }

  

  ngOnInit(): void {
  }
  addTest(){
    this.centersService.addTest(this.test).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.test=new Tests()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }
}
