import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { RegistrationService } from '../Services/registration.service';
import { User } from '../User/user';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User=new User();
  msg:String='';
  errorMsg:String;

  constructor(private loginservice:RegistrationService, private _route:Router) { }

  ngOnInit(): void {
  }

  loginUser(){
       this.loginservice.loginUser(this.user).subscribe((data)=>{
        console.log("data",data);
        this.msg=data;
        this.errorMsg=undefined;
        this.user=new User();
        this._route.navigate(['/loginsuccess']);
      },
       (error)=>{this.errorMsg= error.error; 
        console.log(error.error);
        this.msg=undefined;
      }); 
  }

}
