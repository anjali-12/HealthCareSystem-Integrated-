import {Component, OnInit} from '@angular/core';
import { Center, Tests } from '../center';
import {CentersService} from '../centers.service';
@Component({
    selector: 'app-view',
    templateUrl: './view.component.html',
    styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit{
    tests:Tests[]=[];
    
    modifyTest:Tests=new Tests();
  updateDiv:boolean=false;
  msg:string;
  errorMsg:string;

    constructor(private centersService:CentersService){}
    ngOnInit(){
    
        console.log("Am inside view component");
        this.centersService.viewTests().subscribe(data=>this.tests=data);
        console.log(this.tests);
    }

    deleteTest(testId:number){

        if(confirm("Confirm Deletion of Test Id:"+testId)){
          this.centersService.delTest(testId)
          .subscribe(data=>{
            this.msg=data;
            this.errorMsg=undefined;
    
            this.centersService.viewTests().subscribe(data=>this.tests=data);
            console.log(this.tests);
          },
            error=>{
              this.errorMsg=error.error;
              this.msg=undefined;
            });
    
        }
        
      }
      update(test:Tests)
      {
        console.log(JSON.stringify(test));
        this.modifyTest=test;
        this.updateDiv=true;//make update division visible
      }
      cancel()
      {
        this.updateDiv=false;//make update division invisible
      }
      updateTest(){
        this.updateDiv=false;//make update division invisible
        this.centersService.UpdateTest(this.modifyTest)
              .subscribe(data=>{
                this.msg=data;
                this.errorMsg=undefined;
             
                this.centersService.viewTests().subscribe(data=>this.tests=data);
                console.log(this.tests);
              },
                error=>{
                  this.errorMsg=error.error;
                  this.msg=undefined;
                });
    
      }
    
}