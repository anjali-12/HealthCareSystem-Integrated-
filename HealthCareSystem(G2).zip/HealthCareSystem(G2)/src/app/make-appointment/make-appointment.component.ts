import { Component, OnInit } from '@angular/core';
import { Appointment, NewAppointment, Center, Tests } from '../center';
import { CentersService } from '../centers.service';

@Component({
  selector: 'app-make-appointment',
  templateUrl: './make-appointment.component.html',
  styleUrls: ['./make-appointment.component.css']
})
export class MakeAppointmentComponent implements OnInit {

  newAppointment:NewAppointment=new NewAppointment();
  centers:Center[]=[];
  tests:Tests[]=[];
  msg:String;
  errorMsg:String;
//initialise current date as min date for booking appointement
  minDate = "2020-05-22";//new Date();

  constructor(private appointmentService:CentersService) { }

  ngOnInit(): void {
    //Load all centers from back end
    this.appointmentService.getCenters().subscribe((data)=>{
      console.log("Centers"+JSON.stringify(data));
      this.centers=data;
         //Assign default center
         console.log("default center id:"+this.centers[0].centerId);
         this.newAppointment.centerId=this.centers[0].centerId;
    
    });
      //load all tests from backend
      this.appointmentService.getTests().subscribe((data)=>{
        console.log("Tests"+JSON.stringify(data));
        this.tests=data;
        //assign default test
        console.log("default test id:"+this.tests[0].testId);
        this.newAppointment.testId=this.tests[0].testId;

      });
      
        
  }

  makeAppointment(){
    this.appointmentService.makeAppointment(this.newAppointment).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      },
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }
  

  setCenterId(centerId:number)
  {
    this.newAppointment.centerId=centerId;
  }
  setTestId(testId:number)
  {
    this.newAppointment.testId=testId;
  }

}
