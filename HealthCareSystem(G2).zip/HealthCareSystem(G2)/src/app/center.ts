export class Center {
    centerId:number;
    centerName:string;
    centerLocation:string;
    test:Tests[];
}
export class Tests {
    testId:number;
    testName:string;
}
export class Appointment 
{
    appointmentId:number;
    appointmentDate:Date;
    approved:boolean;
    center:Center;
    test:Tests;
    user:User;
}

export class NewAppointment 
{
    appointmentId:number;
    testId:number;
    userId:number;
    centerId:number;
    appointmentDate:Date;
 
}
export class User {
    userId:number;
    emailId:string;
    userName:string;
    userPassword:string;
    contactNo:string;
    gender:string;
    age:number;

}

