import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CentersService } from './centers.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'HealthCareSystem';

  constructor(private route:Router,private loginService:CentersService){ }

  ngOnInit():void{
    console.log("Am inside app component");
    this.route.navigateByUrl("/home");
  }
  logout()
  {
    this.loginService.logOut();
  }
}
