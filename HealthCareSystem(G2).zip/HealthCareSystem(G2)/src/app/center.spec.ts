import { Center } from './center';

describe('Center', () => {
  it('should create an instance', () => {
    expect(new Center()).toBeTruthy();
  });
});
